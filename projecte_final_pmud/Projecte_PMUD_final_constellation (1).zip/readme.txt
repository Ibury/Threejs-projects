COM INSTAL·LAR EL SERVIDOR NODEJS I EL CLIENT VUEJS


1. INSTAL·LAR EL SERVIDOR, VUE I LES SEVES DEPENDÈNCIES

- Descomprimir la carpeta
- A dins de la carpeta descomprimida executar: sudo npm install

2. IMPORTAR LA BASE DE DADES MYSQL

- mysql -u username -p universe < constellationdatabase.sql

!IMPORTANT si es fa servir un usuari diferent de root, una contrasenya diferent o un nom de la
base de dades diferents s'ha de canviar l'arxiu star.js

3. COM ARRANCAR TOTS ELS SERVEIS

- nodejs star.js

En un altre pestanya del terminal:
- npm install axios
- npm run serve

 Un cop hem executat aquesta comanda començarà a compilar el programa i haurem d'esperar fins que al terminal ens aparegui la direcció del servei amb el seu port que haurem d'obrir al navegador (probablement localhost:8080). 
