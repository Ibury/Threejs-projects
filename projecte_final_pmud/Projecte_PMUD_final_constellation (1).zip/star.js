var express = require('express')
var http = require('http')
var https = require('https')
var app = express()
var bodyParser = require('body-parser');
app.use(bodyParser.json());
var mysql = require('mysql');
var path = require('path');
var cors = require('cors');
app.use(express.urlencoded({extended: true}));
var url="";
var appId="";


db = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	password: 'Toor1234$',
	database: 'universe',
})

const listconstellation = (req, res) => {
	let sql = `SELECT * FROM constellation;`;
	db.query(sql, function(err, data, fields) {
	  if (err) throw err;
	  res.json({
		status: 200,
		data,
		message: "Constellation lists retrieved successfully"
	  })
	})
};

const desconstellation = (req, res) => {
	let sql = `SELECT * FROM constellation ORDER BY name DESC;`;
	db.query(sql, function(err, data, fields) {
	  if (err) throw err;
	  res.json({
		status: 200,
		data,
		message: "Constellation lists retrieved successfully"
	  })
	})
};

const asconstellation = (req, res) => {
	let sql = `SELECT * FROM constellation ORDER BY name ASC;`;
	db.query(sql, function(err, data, fields) {
	  if (err) throw err;
	  res.json({
		status: 200,
		data,
		message: "Constellation lists retrieved successfully"
	  })
	})
};


const createconstellation =  (req, res) => {
	let sqlcompr = `SELECT * FROM constellation WHERE name = ? LIMIT 1`;
	let sql = `INSERT INTO constellation(name, coordinates, size) VALUES (?)`;
	let values = [
		req.body.name,
		req.body.coordinates,
		req.body.size	
	];
	db.query(sqlcompr, req.body.name, function(err, data, fields){
		console.log(data);
		if(data.length===0){
			try{	
				db.query(sql, [values], function(err, data, fields){
					if (err) throw err;
					res.json({
						status: 200,
						message: "New constellation added successfully"
					})
				})	
			} catch (error){
				console.log("error");
			}
			
		}else{
			res.status(404);
			res.send("Name exists");	
		}
	})
}

const updateconstellation = (req,res) => {
	let id = req.params.id;
	let sql = `UPDATE constellation SET name = ? , coordinates = ? , size = ? WHERE id = ?`;
	let values = [req.body.name, req.body.coordinates, req.body.size, id];
	console.log(sql);
	db.query(sql, values, function(err, data, fields){
				if (err) throw err;
				res.json({
					status: 200,
					message: "Constellation updated successfully"
				})
	})
}

const dropconstellation = (req,res) => {
	let sql = `DELETE FROM constellation WHERE id = ?`;
	let id = req.params.id;
	db.query(sql, id, function(err, data, fields){
				if (err) throw err;
				res.json({
					status: 200,
					message: "Constellation deleted successfully"
				})
	})
}

const getstars = (req, res) => {
	let sql = `SELECT s.name,s.size,s.composition,s.age from star s, constellation c  where s.id_constellation=c.id and c.id = ?;`;
	let id = req.params.id;
	console.log(sql);
	db.query(sql, id, function(err, data, fields){
				if (err) throw err;
				res.json({
					status: 200,
					data,
					message: "Star lists successfully"
				})
	})
}

const destar = (req, res) => {
	let sql = `SELECT s.id,s.name,s.size,s.composition,s.age,c.name as nom_constellation FROM star s,constellation c WHERE s.id_constellation=c.id ORDER BY s.name DESC;`;
	db.query(sql, function(err, data, fields) {
	  if (err) throw err;
	  res.json({
		status: 200,
		data,
		message: "Star list retrieved successfully"
	  })
	})
};

const ascstar = (req, res) => {
	let sql = `SELECT s.id,s.name,s.size,s.composition,s.age,c.name as nom_constellation FROM star s,constellation c WHERE s.id_constellation=c.id ORDER BY s.name ASC;`;
	db.query(sql, function(err, data, fields) {
	  if (err) throw err;
	  res.json({
		status: 200,
		data,
		message: "Star list retrieved successfully"
	  })
	})
};

const liststar = (req, res) => {
	let sql = `SELECT s.id,s.name,s.size,s.composition,s.age,c.name as nom_constellation FROM star s,constellation c WHERE s.id_constellation=c.id;`;
	db.query(sql, function(err, data, fields) {
	  if (err) throw err;
	  res.json({
		status: 200,
		data,
		message: "Star list retrieved successfully"
	  })
	})
};

const createstar = (req,res) => {
	let sqlcompr = `SELECT * FROM star WHERE name = ? LIMIT 1`;
	let sql = `INSERT INTO star(name, size, composition, age, id_constellation) VALUES (?)`;
	let values = [
		req.body.name,
		req.body.size,
		req.body.composition,
		req.body.age,
		req.body.id_constellation	
	];
	db.query(sqlcompr, req.body.name, function(err, data, fields){
		console.log(data);
		if(data.length===0){
			try{	
				db.query(sql, [values], function(err, data, fields){
					if (err) throw err;
					res.json({
						status: 200,
						message: "New star added successfully"
					})
				})	
			} catch (error){
				console.log("error");
			}
			
		}else{
			res.status(404);
			res.send("Name exists");	
		}
	})
}

const updatestar = (req,res) => {
	let id = req.params.id;
	let sql = `UPDATE star SET name = ? , size = ?, composition = ? , age = ?, id_constellation = ? WHERE id = ?`;
	let values = [req.body.name, req.body.size, req.body.composition, req.body.age, req.body.id_constellation, id];
	console.log(sql);
	db.query(sql, values, function(err, data, fields){
				if (err) throw err;
				res.json({
					status: 200,
					message: "Star updated successfully"
				})
	})
}

const dropstar = (req,res) => {
	let sql = `DELETE FROM star WHERE id = ?`;
	let id = req.params.id;
	db.query(sql, id, function(err, data, fields){
				if (err) throw err;
				res.json({
					status: 200,
					message: "Star deleted successfully"
				})
	})
}

const getplanets = (req, res) => {
	let sql = `SELECT p.name,p.size,p.type,p.age,p.rings from planet p, star s  where p.id_star=s.id and s.id = ?;`;
	let id = req.params.id;
	console.log(sql);
	db.query(sql, id, function(err, data, fields){
				if (err) throw err;
				res.json({
					status: 200,
					data,
					message: "Planets lists successfully"
				})
	})
}

const desplanet = (req, res) => {
	let sql = `SELECT p.id,p.name,p.size,p.type,p.age,p.rings,s.name as nom_star FROM planet p, star s WHERE p.id_star=s.id ORDER BY p.name DESC;`;
	db.query(sql, function(err, data, fields) {
	  if (err) throw err;
	  res.json({
		status: 200,
		data,
		message: "Planet lists retrieved successfully"
	  })
	})
  };

  const ascplanet = (req, res) => {
	let sql = `SELECT p.id,p.name,p.size,p.type,p.age,p.rings,s.name as nom_star FROM planet p, star s WHERE p.id_star=s.id ORDER BY p.name ASC;`;
	db.query(sql, function(err, data, fields) {
	  if (err) throw err;
	  res.json({
		status: 200,
		data,
		message: "Planet lists retrieved successfully"
	  })
	})
  };

const listplanet = (req, res) => {
	let sql = `SELECT p.id,p.name,p.size,p.type,p.age,p.rings,s.name as nom_star FROM planet p, star s WHERE p.id_star=s.id;`;
	db.query(sql, function(err, data, fields) {
	  if (err) throw err;
	  res.json({
		status: 200,
		data,
		message: "Planet lists retrieved successfully"
	  })
	})
  };

  const createplanet = (req,res) => {
	let sqlcompr = `SELECT * FROM planet WHERE name = ? LIMIT 1`;
	let sql = `INSERT INTO planet(name, size, type, age, rings, id_star) VALUES (?)`;
	let values = [
		req.body.name,
		req.body.size,
		req.body.type,
		req.body.age,
		req.body.rings,
		req.body.id_star	
	];
	db.query(sqlcompr, req.body.name, function(err, data, fields){
		console.log(data);
		if(data.length===0){
			try{	
				db.query(sql, [values], function(err, data, fields){
					if (err) throw err;
					res.json({
						status: 200,
						message: "New planet added successfully"
					})
				})	
			} catch (error){
				console.log("error");
			}
			
		}else{
			res.status(404);
			res.send("Name exists");	
		}
	})
}

const updateplanet = (req,res) => {
	let id = req.params.id;
	let sql = `UPDATE planet SET name = ? , size = ?, type = ? , age = ?, rings = ? , id_star = ? WHERE id = ?`;
	let values = [req.body.name, req.body.size, req.body.type, req.body.age, req.body.rings, req.body.id_star, id];
	console.log(sql);
	db.query(sql, values, function(err, data, fields){
				if (err) throw err;
				res.json({
					status: 200,
					message: "Planet updated successfully"
				})
	})
}

const dropplanet = (req,res) => {
	let sql = `DELETE FROM planet WHERE id = ?`;
	let id = req.params.id;
	db.query(sql, id, function(err, data, fields){
				if (err) throw err;
				res.json({
					status: 200,
					message: "Planet deleted successfully"
				})
	})
}

const getmoons = (req, res) => {
	let sql = `SELECT m.name,m.size,m.type from moon m, planet p  where m.id_planet=p.id and p.id = ?;`;
	let id = req.params.id;
	console.log(sql);
	db.query(sql, id, function(err, data, fields){
				if (err) throw err;
				res.json({
					status: 200,
					data,
					message: "Moons lists successfully"
				})
	})
}

const desmoon = (req, res) => {
	let sql = `SELECT m.id,m.name,m.size,m.type,p.name as nom_planeta FROM moon m,planet p WHERE m.id_planet=p.id ORDER BY m.name DESC;`;
	db.query(sql, function(err, data, fields) {
	  if (err) throw err;
	  res.json({
		status: 200,
		data,
		message: "Moon lists retrieved successfully"
	  })
	})
  };

  const ascmoon = (req, res) => {
	let sql = `SELECT m.id,m.name,m.size,m.type,p.name as nom_planeta FROM moon m,planet p WHERE m.id_planet=p.id ORDER BY m.name ASC;`;
	db.query(sql, function(err, data, fields) {
	  if (err) throw err;
	  res.json({
		status: 200,
		data,
		message: "Moon lists retrieved successfully"
	  })
	})
  };

  const listmoon = (req, res) => {
	let sql = `SELECT m.id,m.name,m.size,m.type,p.name as nom_planeta FROM moon m,planet p WHERE m.id_planet=p.id;`;
	db.query(sql, function(err, data, fields) {
	  if (err) throw err;
	  res.json({
		status: 200,
		data,
		message: "Moon lists retrieved successfully"
	  })
	})
  };

  const createmoon = (req,res) => {
	let sqlcompr = `SELECT * FROM moon WHERE name = ? LIMIT 1`;
	let sql = `INSERT INTO moon(name, size, type, id_planet) VALUES (?)`;
	let values = [
		req.body.name,
		req.body.size,
		req.body.type,
		req.body.id_planet
	];
	db.query(sqlcompr, req.body.name, function(err, data, fields){
		console.log(data);
		if(data.length===0){
			try{	
				db.query(sql, [values], function(err, data, fields){
					if (err) throw err;
					res.json({
						status: 200,
						message: "New moon added successfully"
					})
				})	
			} catch (error){
				console.log("error");
			}
			
		}else{
			res.status(404);
			res.send("Name exists");	
		}
	})
}

const updatemoon = (req,res) => {
	let id = req.params.id;
	let sql = `UPDATE moon SET name = ? , size = ?, type = ? , id_planet = ? WHERE id = ?`;
	let values = [req.body.name, req.body.size, req.body.type, req.body.id_planet, id];
	console.log(sql);
	db.query(sql, values, function(err, data, fields){
				if (err) throw err;
				res.json({
					status: 200,
					message: "Moon updated successfully"
				})
	})
}

const dropmoon = (req,res) => {
	let sql = `DELETE FROM moon WHERE id = ?`;
	let id = req.params.id;
	db.query(sql, id, function(err, data, fields){
				if (err) throw err;
				res.json({
					status: 200,
					message: "Moon deleted successfully"
				})
	})
}

  const listlocalitzacio = (req, res) => {
	let sql = `SELECT * FROM localitzacio`;
	db.query(sql, function(err, data, fields) {
	  if (err) throw err;
	  res.json({
		status: 200,
		data,
		message: "localitzacio retrieved successfully"
	  })
	})
  };

  const logController = (req, res, next) => {
	res.setHeader('Access-Control-Allow-Origin', '*');
	res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
	res.setHeader('Access-Control-Allow-Headers', 'GET, OPTION, PUT, POST, PATCH, DELETE');
	console.log("******************************************");
    console.log('req.method = ' + req.method);
    console.log('req.URL = ' + req.originalUrl);
    console.log('req.body = ' + JSON.stringify(req.body));
    console.log("******************************************");
    next();
  };
  app.options('*',                                   cors());
  app.use('*',                  	          logController);
  app.get('/constellation',		          listconstellation);
  app.get('/desconstellation',		          desconstellation);
  app.get('/asconstellation',		          asconstellation);
  app.post('/newconstellation', 	        createconstellation);
  app.put('/updconstellation/:id',         updateconstellation);
  app.delete('/delconstellation/:id',       dropconstellation);
  app.get('/getstar/:id',						    getstars);
  app.get('/destar',		          				  destar);
  app.get('/ascstar',		          				 ascstar); 
  app.get('/star',				                   	liststar);
  app.post('/newstar',   				          createstar);
  app.put('/updstar/:id',         				  updatestar);
  app.delete('/delstar/:id',       					dropstar);
  app.get('/getplanet/:id',						  getplanets);
  app.get('/desplanet',		          				desplanet);
  app.get('/ascplanet',		          				ascplanet); 
  app.get('/planet',				              listplanet);
  app.post('/newplanet',   				        createplanet);
  app.put('/updplanet/:id',         			updateplanet);
  app.delete('/delplanet/:id',       			  dropplanet);
  app.get('/getmoon/:id',						    getmoons);
  app.get('/desmoon',				          		desmoon);
  app.get('/ascmoon',				          		ascmoon); 
  app.get('/moon',				                   	listmoon);
  app.post('/newmoon',   				          createmoon);
  app.put('/updmoon/:id',         				  updatemoon);
  app.delete('/delmoon/:id',       					dropmoon);
  app.get('/localitzacio/:id',              listlocalitzacio);
  

app.all('*', function(req, res) {
	res.json({
	code: 404,
	message: 'Method not found' });
});

http.createServer(app).listen(8001, () => {
  console.log('Server started at http://localhost:8001');
});
