<template>
<div>
    <button class="btn btn-dark" id="btconst" v-on:click="list_moon">Llunes</button>
    <div v-if="this.seen">
            <list_moon/>
            <br>
            <button class="btn btn-primary" v-on:click="amaga_const">Amaga</button>
    </div>
</div>
</template>
<script>
//import axios from 'axios';
import list_moon from "./moon_list";
export default {
    name: "moon",
    data: ()=>{return{name:'',size:0,type:'',afegir:false,message:false,list:false,seen:false}},
    methods: {
        list_moon:function(){
            this.seen=true;
        },
        amaga_const:function(){
            this.seen=false;
        }
    },
    components: {list_moon},
    props: {}
}

</script>
<style scoped>
button{
  width: 35%;
  border-radius: 15px 15px 15px 15px;
  font-family: Garamond,serif;
  font-size: 1rem;
}
@media only screen and (max-width: 400px){
    #btconst{
        font-size: 1rem;
        width: 60%;
    }
}
</style>