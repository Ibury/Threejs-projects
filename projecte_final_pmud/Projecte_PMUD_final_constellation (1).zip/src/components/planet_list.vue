<template>
  <div>
    <form v-on:submit.prevent="nouplanet">
        <div class="form-group">
        <label id="nomc">Nom</label>
        <input id="nomi" type="text" name="name" v-model="form.name">
        </div>
        <div class="form-group">
        <label id="tc">Tamany</label>
        <input id="tami" type="text" name="name" v-model="form.size">
        </div>
        <div class="form-group">
        <label id="tic">Tipus</label>
        <input id="tii" type="text" name="name" v-model="form.type">
        </div>
        <div class="form-group">
        <label id="ed">Edat</label>
        <input id="edi" type="text" name="name" v-model="form.age">
        </div>
        <div class="form-group">
        <label id="an">Anells</label>
      <select v-model="form.rings">
      <option>Sí</option>
      <option>No</option>
      </select>
        </div>
      <div class="form-group">
      <label id="es">Estrella</label>        
      <select v-model="form.id_star">
      <option v-for="star in allstar" :value="star.id" v-bind:key="star.id" >
        {{ star.name }}
      </option>
      </select>
      </div>
        <input type="submit" class="btn btn-success" value="Afegir planeta">
    </form>
    <button id="b" v-on:click="orderasc()">⬆️</button>
    <button id="b" v-on:click="orderdesc()">⬇️</button>
    <div id="t">
      <b-table-simple hover small caption-top responsive>
        <b-tr>
          <b-th id="nomt">Nom</b-th>
          <b-th id="tat">Tamany</b-th>
          <b-th id="tit">Tipus</b-th>
          <b-th id="edt">Edat</b-th>
          <b-th id="ant">Anells</b-th>
          <b-th id="est">Estrella</b-th>
        </b-tr>
        <b-tr v-for="planet in allplanet" v-bind:key="planet.id">
          <b-td><button id="buttontab" class="btn btn-outline-light" v-on:click="lmoon(planet.id)">{{ planet.name }}</button></b-td>
          <b-td id="sizem">{{ planet.size }}</b-td>
          <b-td id="typem">{{ planet.type }}</b-td>
          <b-td id="agem">{{ planet.age }}</b-td>
          <b-td id="ringm">{{ planet.rings }}</b-td>
          <b-td id="starm">{{ planet.nom_star}}</b-td>
          <b-td><button id="be" v-on:click="editplanet(planet.id)" class="btn btn-warning">Editar</button></b-td>
          <b-td><button id="bb" v-on:click="esbplanet(planet.id)" class="btn btn-danger">Borrar</button></b-td>
        </b-tr>
      </b-table-simple> 
    </div>
      <table id="tab2" class="table table-sm" v-if="this.mostra">
      <tr>
        <th>Nom</th>
        <th>Tamany</th>
        <th>Tipus</th>
      </tr>
      <tr v-for="moon in allmoon" v-bind:key="moon.id">
        <td>{{ moon.name }}</td>
        <td>{{ moon.size }}</td>
        <td>{{ moon.type }}</td>
      </tr>
    </table>
    <div v-if="this.myModel">
      <transition name="model">
      <div class="modal-mask">
        <div class="modal-wrapper">
        <div class="modal-dialog">
          <div style="background-color: rgba(119, 165, 177, 0.5);" class="modal-content">
          <div class="modal-header">
            <h4 style="color:white;" class="modal-title">Edita planeta</h4>
            <button style="color:white;" type="button" class="close" @click="myModel=false"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <form v-on:submit.prevent="submit_const">
            <label id="n2">Nom</label>
            <input type="text" class="form-control" v-model="form.name" />
            <label id="t2">Tamany</label>
            <input type="text" class="form-control" v-model="form.size" />
            <label id="ti2">Tipus</label>
            <input type="text" class="form-control" v-model="form.type" />
            <label id="ed2">Edat</label>
            <input type="text" class="form-control" v-model="form.age" />
            <label id="an2">Anells</label><br>
            <select v-model="form.rings">
            <option>Sí</option>
            <option>No</option>
            </select>  <br>          
            <label id="es2">Estrella</label><br>
            <select v-model="form.id_star">
              <option v-for="star in allstar" :value="star.id" v-bind:key="star.id" >
                {{ star.name }}
              </option>
            </select>
            <div align="center">
            <input id="b2" type="submit" class="btn btn-success" value="Edita planeta">
            </div>
            </form>
          </div>
          </div>
        </div>
        </div>
      </div>
      </transition>
    </div>
  </div>
</template>
<script>
import axios from "axios";
let id2 = "";
export default {
    name: "list_planet",
    data: function(){ return{ allstar:[], allplanet: [], allmoon: [], myModel:false,seen:true,mostra:false,form:{name:'',size:0,type:'',age:0,rings:'',id_star:0}}},
    created: function(){
        axios.get("http://localhost:8001/star")
        .then((res => {
            console.log(res);
            this.allstar=res.data.data;
        }))
        axios.get("http://localhost:8001/planet")
        .then((res => {
            console.log(res);
            this.allplanet=res.data.data;
        })) 
    },
    methods: {
      refresca(){
        axios.get("http://localhost:8001/planet")
        .then((res => {
            console.log(res);
            this.allplanet=res.data.data;
        }))
      },
      submit_const(){
        const url='http://localhost:8001/updplanet/'+id2;
        console.log(url);
        axios.put(url,this.form)
        .then((res => {
            console.log(res);
            this.refresca();
        }))
      }, 
      nouplanet(){
        const url='http://localhost:8001/newplanet';
        console.log(url);
        axios.post(url,this.form)
        .then((res => {
            console.log(res);
            this.refresca();
            this.seen=false;
        }))
      },
      editplanet(planetid){
          console.log('edit ', planetid);
          this.myModel = true;
          id2=planetid;
      },
      esbplanet(planetid){
          console.log('delete ', planetid);
          const url='http://localhost:8001/delplanet/'+planetid;
          axios.delete(url).then(res => {
              console.log('Deleted planet',res);
              this.refresca();
          });
      },
      lmoon(planetid){
        this.mostra=true;
        const url='http://localhost:8001/getmoon/'+planetid;
        axios.get(url)
        .then((res => {
            console.log(res);
            this.allmoon=res.data.data;
        }))
      },
      orderdesc(){
          axios.get("http://localhost:8001/desplanet")
          .then((res => {
            console.log(res);
            this.allplanet=res.data.data;
        }))
      },
      orderasc(){
        axios.get("http://localhost:8001/ascplanet")
        .then((res => {
            console.log(res);
            this.allplanet=res.data.data;
        }))
      }
    }
      
}
</script>
<style scoped>
#t{
  margin: auto;
  color: white;
  background-color: rgba(119, 165, 177, 0.7);
  font-size: 18px;
  border-radius: 15px 15px 15px 15px;
}
th{
  padding-top: 2%;
}
td{
  padding-bottom: 2%;
}
form{
  color: white;
}
#buttontab{
  width: 100%;
  font-size: 1rem;
  margin-left: 12%;
}


#nomc{
  margin-top:2%;
  margin-right: 1%;
  font-size:1rem;
}

#tc{
  margin-left: -1%;
  margin-right: 1%;
  font-size:1rem;
}

#tic{
  margin-right: 1%;
  font-size:1rem;
}

#ed{
  margin-right: 1%;
  font-size:1rem;
}

#an{
  margin-right: 1%;
  font-size:1rem;
}

#es{
  margin-right: 1%;
  font-size:1rem;
}
#b{
  margin-top: 2%;
  margin-bottom: 2%;
}

#tab2{
  margin-top:4%;
  color: white;
  background-color: rgba(119, 165, 177, 0.7);
  font-size: 18px;
  border-radius: 15px 15px 15px 15px;
}
#n2{
  color:white;
}
#t2{
  margin-top:2%;
  color:white;
}
#ti2{
  margin-top:2%;
  color:white;
}
#ed2{
  margin-top:2%;
  color:white;
}
#an2{
  margin-top:2%;
  color:white;
}
#es2{
  margin-top:2%;
  color:white;
}
#b2{
  margin-top:3%;
}
#nomt{
  color:white;
  padding-left:3%;
}
#tat{
  color:white;
}
#tit{
  color:white;
}
#edt{
  color:white;
}
#ant{
  color:white;
}
#est{
  color:white;
}
#sizem{
  color:white;
}
#typem{
  color:white;
}
#agem{
  color:white;
}
#ringm{
  color:white;
}
#starm{
  color:white;
}
@media only screen and (max-width: 500px){
    #tami{
      width: 46%;
    }
    #t{
      font-size: 0.95rem;
    }
    #buttontab{
      font-size: 0.9rem;
      width: 95%;
    }
    #bb{
      font-size: 0.9rem;
    }
    #be{
      font-size: 0.9rem;
    }
    #tab2{
      font-size:1rem;
    }
    #est{
      display:none;
    }
    #starm{
      display:none;
    }
}
@media only screen and (max-width: 400px){
    #t{
      font-size:16px;
    }
    #nomi{
      margin-top:3%;
    }
    #tami{
      width: 67%;
    }
    #tii{
      width:71%;
    }
    #tat{
      display:none;
    }
    #tit{
      display:none;
    }
    #edt{
      display:none;
    }
    #ant{
      display:none;
    }
    #sizem{
      display:none;
    }
    #typem{
      display:none;
    }
    #agem{
      display:none;
    }
    #ringm{
      display:none;
    }
}
</style>