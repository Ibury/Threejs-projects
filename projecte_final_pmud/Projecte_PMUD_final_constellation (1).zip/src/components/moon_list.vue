<template>
  <div>
    <form v-on:submit.prevent="noumoon">
        <div class="form-group">
        <label id="nomc">Nom</label>
        <input type="text" name="name" v-model="form.name">
        </div>
        <div class="form-group">
        <label id="tam">Tamany</label>
        <input id="tami" type="text" name="name" v-model="form.size">
        </div>
        <div class="form-group">
        <label id="ti">Tipus</label>
        <input type="text" name="name" v-model="form.type">
        </div>
        <div class="form-group">
        <label id="pl">Planeta</label>
        <select v-model="form.id_planet">
      <option v-for="planet in allplanet" :value="planet.id" v-bind:key="planet.id" >
        {{ planet.name }}
      </option>
      </select>
        </div>
        <input type="submit" class="btn btn-success" value="Afegir lluna">
    </form>
    <button id="b" v-on:click="orderasc()">⬆️</button>
    <button id="b" v-on:click="orderdesc()">⬇️</button>
    <div id="t">
    <b-table-simple hover small caption-top responsive>
      <b-tr>
        <b-th id="nomt">Nom</b-th>
        <b-th id="tat">Tamany</b-th>
        <b-th id="tit">Tipus</b-th>
        <b-th id="plt">Planeta</b-th>
      </b-tr>
      <b-tr v-for="moon in allmoon" v-bind:key="moon.id">
        <b-td id="nomm">{{ moon.name }}</b-td>
        <b-td id="sizem">{{ moon.size }}</b-td>
        <b-td id="typem">{{ moon.type }}</b-td>
        <b-td id="plam">{{ moon.nom_planeta}}</b-td>
        <b-td><button id="be" v-on:click="editmoon(moon.id)" class="btn btn-warning">Editar</button></b-td>
        <b-td><button id="bb" v-on:click="esbmoon(moon.id)" class="btn btn-danger">Borrar</button></b-td>
      </b-tr>
    </b-table-simple> 
    </div>
    <div v-if="this.myModel">
      <transition name="model">
      <div class="modal-mask">
        <div class="modal-wrapper">
        <div class="modal-dialog">
          <div style="background-color: rgba(119, 165, 177, 0.5);" class="modal-content">
          <div class="modal-header">
            <h4 style="color:white;" class="modal-title">Edita planeta</h4>
            <button style="color:white" type="button" class="close" @click="myModel=false"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <form v-on:submit.prevent="submit_const">
            <label>Nom</label>
            <input type="text" class="form-control" v-model="form.name" />
            <label id="t2">Tamany</label>
            <input type="text" class="form-control" v-model="form.size" />
            <label id="ti2">Tipus</label>
            <input type="text" class="form-control" v-model="form.type" />
            <label id="pl2">Planeta</label><br>
            <select v-model="form.id_planet">
              <option v-for="planet in allplanet" :value="planet.id" v-bind:key="planet.id" >
                {{ planet.name }}
              </option>
            </select>
            <div align="center">
            <input id="b2" type="submit" class="btn btn-success" value="Edita lluna">
            </div>
            </form>
          </div>
          </div>
        </div>
        </div>
      </div>
      </transition>
    </div>
  </div>
</template>
<script>
import axios from "axios";
let id2 = "";
export default {
    name: "list_moon",
    data: function(){ return{ allplanet:[], allmoon: [],myModel:false,seen:true,form:{name:'',size:0,type:'',id_planet:0}}},
    created: function(){
       
        axios.get("http://localhost:8001/planet")
        .then((res => {
            console.log(res);
            this.allplanet=res.data.data;
        }))
         axios.get("http://localhost:8001/moon")
        .then((res => {
            console.log(res);
            this.allmoon=res.data.data;
        }))
    },
    methods: {
      refresca(){
        axios.get("http://localhost:8001/moon")
        .then((res => {
            console.log(res);
            this.allmoon=res.data.data;
        }))
      },
      submit_const(){
        const url='http://localhost:8001/updmoon/'+id2;
        console.log(url);
        axios.put(url,this.form)
        .then((res => {
            console.log(res);
            this.refresca();
        }))
      }, 
      noumoon(){
        const url='http://localhost:8001/newmoon';
        console.log(url);
        axios.post(url,this.form)
        .then((res => {
            console.log(res);
            this.refresca();
            this.seen=false;
        }))
      },
      editmoon(moonid){
          console.log('edit ', moonid);
          this.myModel = true;
          id2=moonid;
      },
      esbmoon(moonid){
          console.log('delete ', moonid);
          const url='http://localhost:8001/delmoon/'+ moonid;

          axios.delete(url).then(res => {
              console.log('Deleted moon',res);
              this.refresca();
          });
      },
      orderdesc(){
          axios.get("http://localhost:8001/desmoon")
          .then((res => {
            console.log(res);
            this.allmoon=res.data.data;
        }))
      },
      orderasc(){
        axios.get("http://localhost:8001/ascmoon")
        .then((res => {
            console.log(res);
            this.allmoon=res.data.data;
        }))
      }
      
    }
}
</script>
<style scoped>
#t{
  margin: auto;
  color: white;
  background-color: rgba(119, 165, 177, 0.7);
  font-size: 18px;
  border-radius: 15px 15px 15px 15px;
}
th{
  padding-top: 2%;
}

form{
  color: white;
}
#nomc{
  margin-top:2%;
  margin-right: 1%;
  font-size:1rem;
}
#tam{
  margin-left:-1%;
  margin-right:0.5%;
  font-size:1rem;
}

#ti{
  margin-right:0.5%;
  font-size:1rem;
}

#pl{
  margin-right:0.5%;
  font-size:1rem;
}
#b{
  margin-top: 2%;
  margin-bottom: 2%;
}

#tab2{
  margin-top:8%;
}
#n2{
  color:white;
}


#t2{
  margin-top:2%;
  color:white;
}
#ti2{
  margin-top:2%;
}

#pl2{
  margin-top:2%;
}
#b2{
  margin-top:3%;
}
#nomt{
  color:white;
}
#tat{
  color:white;
}
#tit{
  color:white;
}
#plt{
  color:white;
}
#nomm{
  color:white;
}
#sizem{
  color:white;
}
#typem{
  color:white;
}
#plam{
  color:white;
}
@media only screen and (max-width: 500px){
    #tami{
      width: 45%;
    }
    #t{
      font-size: 1.1rem;
    }
    #buttontab{
      font-size: 0.9rem;
      width: 95%;
    }
}
@media only screen and (max-width: 400px){
    #t{
      font-size:16px;
    }
    #tami{
      width: 68%;
    }
    #plam{
      display:none;
    }
    #plt{
      display:none;
    }
    #be{
      font-size:14px;
    }
    #bb{
      font-size:14px;
    }
}
</style>