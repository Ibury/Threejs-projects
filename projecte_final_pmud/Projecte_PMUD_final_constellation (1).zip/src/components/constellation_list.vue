<template>
  <div>
    <form v-on:submit.prevent="novaconst">
        <div class="form-group">
        <label id="nomc">Nom</label>
        <input id="nomi" type="text" name="name" placeholder="Nom" v-model="form.name">
        </div>
        <div class="form-group">
        <label id="coor">Coordenades(lat,long)</label>
        <input id="coori" type="text" name="name" placeholder="40,50" v-model="form.coordinates">
        </div>
          <div class="form-group">
        <label id="tam">Tamany</label>
        <input id="tami" type="text" name="name" placeholder="120000" v-model="form.size">
          </div>
        <input type="submit" class="btn btn-success" value="Afegir constel·lació">
    </form>
    <button id="b" v-on:click="orderasc()">⬆️</button>
    <button id="b" v-on:click="orderdesc()">⬇️</button>
    <div id="t">
      <b-table-simple hover small caption-top responsive>
        <b-tr>
          <b-th id="nomt">NOM</b-th>
          <b-th id="coort">COORDENADES</b-th>
          <b-th id="tamt">TAMANY</b-th>
        </b-tr>
        <b-tr v-for="constell in allconstellation" v-bind:key="constell.id">
          <b-td><button id="buttontab" class="btn btn-outline-light" v-on:click="lstar(constell.id)">{{ constell.name }}</button></b-td>
          <b-td id="coorm">{{ constell.coordinates }}</b-td>
          <b-td id="sizem">{{ constell.size }}</b-td>
          <b-td><button v-on:click="editconst(constell.id)" class="btn btn-warning">Editar</button></b-td>
          <b-td><button v-on:click="esbconst(constell.id)" class="btn btn-danger">Borrar</button></b-td>
        </b-tr>
      </b-table-simple>
    </div>
    <table id="tab2" class="table table-sm" v-if='this.mostra'>
      <tr>
        <th scope="col">Nom</th>
        <th scope="col">Tamany</th>
        <th scope="col">Composició</th>
        <th scope="col">Edat</th>
      </tr>
      <tr v-for="star in allstar" v-bind:key="star.id">
        <td>{{ star.name }}</td>
        <td>{{ star.size }}</td>
        <td>{{ star.composition }}</td>
        <td>{{ star.age }}</td>
      </tr>
    </table> 
    <div  v-if="this.myModel">
      <transition name="model">
      <div class="modal-mask">
        <div class="modal-wrapper">
        <div class="modal-dialog">
          <div style="background-color: rgba(119, 165, 177, 0.5);" class="modal-content">
          <div class="modal-header">
            <h4 style="color:white" class="modal-title">Edita constel·lació</h4>
            <button style="color:white" type="button" class="close" @click="myModel=false"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <form v-on:submit.prevent="submit_const">
            <label id="n2">Nom</label>
            <input type="text" class="form-control" v-model="form.name" />
            <label id="c2">Coordenades</label>
            <input id="ci2" type="text" class="form-control" v-model="form.coordinates" />
            <label id="t2">Tamany</label>
            <input id="ti2" type="text" class="form-control" v-model="form.size" />
            <div align="center">
            <input type="submit" class="btn btn-success" value="Edita constel·lació">
            </div>
            </form>
          </div>
          </div>
        </div>
        </div>
      </div>
      </transition>
    </div>
  </div>
</template>
<script>
import axios from "axios";
let id2 = "";
export default {
    name: "list_constellation",
    data: function(){ return{ allstar: [], allconstellation: [],myModel:false,seen:true,mostra:false,form:{name:"",coordinates:"",size:0}}},
    created: function(){
        axios.get("http://localhost:8001/constellation")
        .then((res => {
            console.log(res);
            this.allconstellation=res.data.data;
        }))
    },
    methods: {
      refresca(){
        axios.get("http://localhost:8001/constellation")
        .then((res => {
            console.log(res);
            this.allconstellation=res.data.data;
        }))
      },
      submit_const(){
        const url='http://localhost:8001/updconstellation/'+id2;
        console.log(url);
        axios.put(url,this.form)
        .then((res => {
            console.log(res);
            this.refresca();
        }))
        
      }, 
      novaconst(){
        const url='http://localhost:8001/newconstellation';
        console.log(url);
        axios.post(url,this.form)
        .then((res => {
            console.log(res);
            this.refresca();
            this.seen=false;
        }))
      },
      editconst(constellid){
          console.log('edit ', constellid);
          this.myModel = true;
          id2=constellid;
      },
      esbconst(constellid){
          console.log('delete ', constellid);
          const url='http://localhost:8001/delconstellation/'+constellid;
          axios.delete(url).then(res => {
              console.log('Deleted constellation',res);
              this.refresca();
          });
      },
      lstar(constellid){
        this.mostra=true;
        const url='http://localhost:8001/getstar/'+constellid;
        axios.get(url)
        .then((res => {
            console.log(res);
            this.allstar=res.data.data;
        }))
      },
      orderdesc(){
          axios.get("http://localhost:8001/desconstellation")
          .then((res => {
            console.log(res);
            this.allconstellation=res.data.data;
        }))
      },
      orderasc(){
        axios.get("http://localhost:8001/asconstellation")
        .then((res => {
            console.log(res);
            this.allconstellation=res.data.data;
        }))
      }
      
    }
}
</script>
<style scoped>
#t{
  margin: auto;
  color: white;
  background-color: rgba(119, 165, 177, 0.7);
  font-size: 18px;
  border-radius: 15px 15px 15px 15px;
}
th{
  padding-top: 2%;
}
td{
  padding-bottom: 2%;
}

form{
  color: white;
}
#buttontab{
  width: 100%;
  font-size: 1rem;
  margin-left: 12%;
}


#nomc{
  margin-top:2%;
  margin-right: 1%;
  font-size:1rem;
}

#coor{
  margin-left:-7%;
  margin-right:1%;
  font-size:1rem;
}

#tam{
  margin-left:-1%;
  margin-right:1%;
  font-size:1rem;
}

#b{
  margin-top: 2%;
  margin-bottom: 2%;
}

#nomt{
  padding-left:5%;
  color:white;
}
#tab2{
  margin-top:4%;
  color: white;
  background-color: rgba(119, 165, 177, 0.7);
  font-size: 18px;
  border-radius: 15px 15px 15px 15px;
}
#n2{
  color:white;
}
#c2{
  color:white;
  margin-top:2%;
}
#ci2{
  margin-bottom:1.5%;
}
#t2{
  margin-top:-0.5px;
  color:white;
}
#ti2{
  margin-bottom:3%;
}

#coort{
  color:white;
}
#tamt{
  color:white;
}
#coorm{
  color:white;
}
#sizem{
  color:white;
}
#nomi{
  margin-top:3%;
  width: 34%;
  margin-left:1%;
}
#coori{
  width: 34%;
}
#tami{
  width: 34%;
}
@media only screen and (max-width: 500px){
    #t{
      font-size:16px;
    }
    #nomi{
        margin-top:3%;
        width: 64%;
        margin-left:1%;
    }
    #coori{
        width: 45%;
    }
    #tami{
        width: 61%;
    }
}
@media only screen and (max-width: 400px){
    #t{
      font-size:13px;
    }
    #buttontab{
      width: 95%;
      font-size:1rem;
    }
    #coort{
        display:none;
    }
    #tamt{
        display:none;
    }
    #coorm{
        display:none;
    }
    #sizem{
        display:none;
    }
    #nomi{
        width: 65%;
    }
    #coori{
        width: 35%;
    }
    #tami{
        width: 61%;
    }
    
}
</style>