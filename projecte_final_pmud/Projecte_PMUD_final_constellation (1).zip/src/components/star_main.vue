<template>
<div>
    <button class="btn btn-dark" id="btconst" v-on:click="list_const">Estrelles</button>
    <div v-if="this.seen">
            <list_star/>
            <br>
            <button class="btn btn-primary" v-on:click="amaga_const">Amaga</button>
    </div>
</div>
</template>
<script>
//import axios from 'axios';
import list_star from "./star_list";
export default {
    name: "star",
    data: ()=>{return{name:'',size:0,composition:'',age:0,afegir:false,message:false,list:false,seen:false}},
    methods: {
        list_const:function(){
            this.seen=true;
        },
        amaga_const:function(){
            this.seen=false;
        }
    },
    components: {list_star},
    props: {}
}

</script>
<style scoped>
button{
    width: 35%;
  border-radius: 15px 15px 15px 15px;
  font-family: Garamond,serif;
  font-size: 1rem;
}
@media only screen and (max-width: 400px){
    #btconst{
        font-size: 1rem;
        width: 60%;
    }
}
</style>