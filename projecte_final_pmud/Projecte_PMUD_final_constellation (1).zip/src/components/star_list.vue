<template>
  <div>
    <form v-on:submit.prevent="novastar">
        <div class="form-group">
        <label id="nomc">Nom</label>
        <input id="nomi" type="text" name="name" v-model="form.name">
        </div>
        <div class="form-group">
        <label id="tam">Tamany</label>
        <input id="tami" type="text" name="name" v-model="form.size">
        </div>
        <div class="form-group">
        <label id="com">Composició</label>
        <input id="comi" type="text" name="name" v-model="form.composition">
        </div>
        <div class="form-group">
        <label id="ed">Edat</label>
        <input id="edi" type="text" name="name" v-model="form.age">
        </div>
        <div class="form-group">
        <label id="con">Constel·lació</label>
        <select  v-model="form.id_constellation">
          <option v-for="constell in allconstellation" :value="constell.id" v-bind:key="constell.id" >
          {{ constell.name }}
          </option>
        </select>
        </div>
        <input type="submit" class="btn btn-success" value="Afegir estrella">
    </form>
    <button id="b" v-on:click="orderasc()">⬆️</button>
    <button id="b" v-on:click="orderdesc()">⬇️</button>
    <div id="t">
      <b-table-simple hover small caption-top responsive>
        <b-tr>
          <b-th id="nomt">Nom</b-th>
          <b-th id="ta">Tamany</b-th>
          <b-th id="comt">Composició</b-th>
          <b-th id="edt">Edat</b-th>
          <b-th id="consta">Constel·lació</b-th>
        </b-tr>
        <b-tr v-for="star in allstar" v-bind:key="star.id">
          <b-td><button id="buttontab" class="btn btn-outline-light" v-on:click="lplanet(star.id)">{{ star.name }}</button></b-td>
          <b-td id="sizem">{{ star.size }}</b-td>
          <b-td id="compm">{{ star.composition }}</b-td>
          <b-td id="agem">{{ star.age }}</b-td>
          <b-td id="constm">{{ star.nom_constellation}}</b-td>
          <b-td><button v-on:click="editstar(star.id)" class="btn btn-warning">Editar</button></b-td>
          <b-td><button v-on:click="esbstar(star.id)" class="btn btn-danger">Borrar</button></b-td>
        </b-tr>
      </b-table-simple>
    </div>
    <table id="tab2" class="table table-sm" v-if="this.mostra">
      <tr>
        <th>Nom</th>
        <th>Tamany</th>
        <th>Tipus</th>
        <th>Edat</th>
        <th>Anells</th>
      </tr>
      <tr v-for="planet in allplanet" v-bind:key="planet.id">
        <td>{{ planet.name }}</td>
        <td>{{ planet.size }}</td>
        <td>{{ planet.type }}</td>
        <td>{{ planet.age }}</td>
        <td>{{ planet.rings }}</td>
      </tr>
      </table>  
    <div v-if="this.myModel">
      <transition name="model">
      <div class="modal-mask">
        <div class="modal-wrapper">
        <div class="modal-dialog">
          <div style="background-color: rgba(119, 165, 177, 0.5);" class="modal-content">
          <div class="modal-header">
            <h4 style="color:white" class="modal-title">Edita estrella</h4>
            <button style="color:white" type="button" class="close" @click="myModel=false"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body">
            <form v-on:submit.prevent="submit_const">
            <label id="n2">Nom</label>
            <input type="text" class="form-control" v-model="form.name" />
            <label id="t2">Tamany</label>
            <input type="text" class="form-control" v-model="form.size" />
            <label id="c2">Composició</label>
            <input type="text" class="form-control" v-model="form.composition" />
            <label id="e2">Edat</label>
            <input type="text" class="form-control" v-model="form.age" />
            <label id="con2">Constel·lació</label><br>
            <select v-model="form.id_constellation">
              <option v-for="constell in allconstellation" :value="constell.id" v-bind:key="constell.id" >
                {{ constell.name }}
              </option>
            </select>
            <div align="center">
            <input id="b2" class="btn btn-success" type="submit" value="Edita estrella">
            </div>
            </form>
          </div>
          </div>
        </div>
        </div>
      </div>
      </transition>
    </div>
  </div>
</template>
<script>
import axios from "axios";
let id2 = "";
export default {
    name: "list_star",
    data: function(){ return{ allconstellation: [], allstar: [], allplanet: [],myModel:false,seen:true,mostra:false,form:{name:'',size:0,composition:'',age:0,id_constellation:0}}},
    created: function(){
        axios.get("http://localhost:8001/constellation")
        .then((res => {
            console.log(res);
            this.allconstellation=res.data.data;
        }))
        axios.get("http://localhost:8001/star")
        .then((res => {
            console.log(res);
            this.allstar=res.data.data;
            
        }))
    },
    methods: {
      refresca(){
        axios.get("http://localhost:8001/star")
        .then((res => {
            console.log(res);
            this.allstar=res.data.data;
        }))
      },
      submit_const(){
        const url='http://localhost:8001/updstar/'+id2;
        console.log(url);
        axios.put(url,this.form)
        .then((res => {
            console.log(res);
            this.refresca();
        }))
      }, 
      novastar(){
        const url='http://localhost:8001/newstar';
        console.log(url);
        axios.post(url,this.form)
        .then((res => {
            console.log(res);
            this.refresca();
            this.seen=false;
        }))

      },
      editstar(starid){
          console.log('edit ', starid);
          this.myModel = true;
          id2=starid;
      },
      esbstar(starid){
          console.log('delete ', starid);
          const url='http://localhost:8001/delstar/'+starid;
          axios.delete(url).then(res => {
              console.log('Deleted star',res);
              this.refresca();
          });
      },
      lplanet(starid){
        this.mostra=true;
        const url='http://localhost:8001/getplanet/'+starid;
        axios.get(url)
        .then((res => {
            console.log(res);
            this.allplanet=res.data.data;
        }))
      },
      orderdesc(){
          axios.get("http://localhost:8001/destar")
          .then((res => {
            console.log(res);
            this.allstar=res.data.data;
        }))
      },
      orderasc(){
        axios.get("http://localhost:8001/ascstar")
        .then((res => {
            console.log(res);
            this.allstar=res.data.data;
        }))
      }
      
    }
    
}
</script>
<style scoped>
#t{
  margin: auto;
  color: white;
  background-color: rgba(119, 165, 177, 0.7);
  font-size: 18px;
  border-radius: 15px 15px 15px 15px;
}
th{
  padding-top: 2%;
}
td{
  padding-bottom: 2%;
}
form{
  color: white;
}
#buttontab{
  width: 100%;
  font-size: 1rem;
  margin-left: 12%;
}


#nomc{
  margin-top:2%;
  margin-right: 1.5%;
  font-size:1rem;
}

#coor{
  margin-left:-7%;
  margin-right:1%;
  font-size:1rem;
}

#tam{
  margin-left:-1%;
  margin-right:1.5%;
  font-size:1rem;
}

#com{
  margin-left:-2.5%;
  margin-right:1.5%;
  font-size:1rem;
}

#ed{
 margin-right:1%;
 font-size:1rem;
}

#con{
  margin-right:1%;
  font-size:1rem;
}

#b{
  margin-top: 2%;
  margin-bottom: 2%;
}

#tab2{
  margin-top:4%;
  color: white;
  background-color: rgba(119, 165, 177, 0.7);
  font-size: 18px;
  border-radius: 15px 15px 15px 15px;
}
#n2{
  color:white;
}
#c2{
  color:white;
  margin-top:2%;
}
#t2{
  color:white;
  margin-top:2%;
}
#e2{
  color:white;
  margin-top:2%;
}

#con2{
  margin-top:2%;
}

#b2{
  margin-top: 3%;
}
#nomt{
  padding-left:3%;
  color:white;
}
#ta{
  color:white;
}
#comt{
  color:white;
}
#edt{
  color:white;
}
#consta{
  color:white;
}
#sizem{
  color:white;
}
#compm{
  color:white;
}
#agem{
  color:white;
}
#constm{
  color:white;
}
#tami{
  width:25%;
}
#comi{
  width:23%;
}
@media only screen and (max-width: 500px){
    #t{
      font-size:16px;
    }
    #nomi{
        margin-top:3%;
        width: 50%;
        margin-left:1%;
    }
    #tami{
        width: 48%;
    }
    #comi{
        width: 44%;
    }
    #edi{
        width: 53%;
    }
    #consta{
        display:none;
    }
    #constm{
      display:none;
    }
}
@media only screen and (max-width: 400px){
    #t{
      font-size:13px;
    }
    #buttontab{
      width: 95%;
      font-size:1rem;
    }
    #coort{
        display:none;
    }
    #tamt{
        display:none;
    }
    #coorm{
        display:none;
    }
    #sizem{
        display:none;
    }
    
    #compm{
      display:none;
    }
    #agem{
      display:none;
    }
    #constm{
     display:none;
    }
    #edt{
      display:none;
    }
    #nomt{
      padding-left:5%;
      color:white;
      font-size:1rem;
    }
    #ta{
      color:white;
      font-size:1rem;
      display:none;
    }
    #comt{
      color:white;
      font-size:1rem;
      display:none;
    }
    #tab2{
      font-size: 0.9rem;
    }
    #nomi{
        margin-top:3%;
        width: 50%;
        margin-left:1%;
    }
    #tami{
        width: 46%;
    }
    #comi{
        width: 39%;
    }
    #edi{
        width: 53%;
    }
}
</style>