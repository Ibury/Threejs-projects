<template>
	<div id="app"  :style="image" class="image">
		<h1 id="title">&#127756; Milky Way APP &#127756;</h1>
				<constellation msg="Welcome to Your Vue.js App"/><br>
				<star msg="Welcome"/><br>
				<planet msg="Welcome"/><br>
				<moon msg="Welcome"/>
			<div>
				<img src="https://raw.githubusercontent.com/Ibury/Threejs-projects/main/constellation-northen-hemisphere.png"  width="50%" height="50%">
				<img src="https://raw.githubusercontent.com/Ibury/Threejs-projects/main/constellation-southern-hemisphere.png"  width="50%" height="50%">
			</div>	
	</div>
</template>

<script>
import constellation from './components/constellation_main.vue'
import star from './components/star_main.vue'
import planet from './components/planet_main.vue'
import moon from './components/moon_main.vue'
export default {
	name:'App',
	data: function(){ return{ seenn:true, seens:true}},
	components: {
		constellation,
		star,
		planet,
		moon
	},
	methods: {
		
	}
}
</script>

<style>

#app{
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.image {
		background-repeat: no-repeat;
		background: url("https://www.xtrafondos.com/wallpapers/estrellas-de-la-via-lactea-4047.jpg") no-repeat center center fixed;
		-webkit-background-size: cover;
		-moz-background-size: cover;
		-o-background-size: cover;
		background-size: cover;
		width:100%;
}
img{
	opacity: 1;
}
#divimg{
	margin:auto;
	width: 80%;
	background-color: rgba(119, 165, 177, 0.8);
}
#title{
	font-family: Garamond,serif;
	font-style: italic;
	color:white;
}
@media only screen and (max-width: 400px){
	#title{
		font-size:1.7rem;
	}

}
</style>